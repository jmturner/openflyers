/* iubito's menu - http://iubito.free.fr/prog/menu.php - configuration du javascript */

/* position du menu par rapport au haut de l'�cran ou de la page.
	0 = le menu est tout en haut. en px */
//var top_menu=2;

/* position des sous-menus par rapport au haut de l'�cran ou de la page. Il faut pr�voir
	la hauteur des menus, donc ne pas mettre 0 et faire "� t�ton". en px*/
//var top_ssmenu=25;

/* Comme le menu peut se superposer avec le texte de la page, il est possible de faire
	descendre un peu la page (on augmente la marge du haut) pour a�rer un peu la page,
	une quarantaine de pixel c'est pas mal. en px*/
//var marge_en_haut_de_page=45;

/* Position gauche du menu, en px. */
//var left_menu=0;

/* On est oblig� de d�finir une largeur pour les menus. */
//var largeur_menu=85;

/* Largeur des sous-menus, pour IE uniquement, les autres navigateurs respectent la largeur
	auto. Mettez "auto" uniquement si vous �tes s�r d'avoir mis des &nbsp; � la place des
	espace dans les items ! */
//var largeur_sous_menu=200;

/* ... pour mettre un peu d'espace entre les menus ! */
//var espace_entre_menus=5;

/* Quand la souris quitte un sous-menu, si le sous-menu dispara&icirc;t imm�diatement,
	cela g�ne l'utilisateur. Alors on peut mettre un d�lai avant disparition du sous-menu.
	500 ms c'est bien :-) */
//var delai=650; // en milliseconde

/* TRES IMPORTANT !
	Il faut mettre ici le nombre de menu, le script n'est pas capable de compter tout
	seul ! :-p Donc si votre code va jusqu'� <p id="menu5"...> il faut mettre 5. */
//var nbmenu=4;

/* Mettez � true si vous souhaitez que le menu soit toujours visible.
	Mettez false si vous ne le souhaitez pas, dans ce cas le menu "dispara�tra" quand vous
	descendrez dans la page. */
//var suivre_le_scroll=true;



var timeout; //ne pas toucher, c'est pour d�clarer la variable
var agt = navigator.userAgent.toLowerCase();
var isMac = (agt.indexOf('mac') != -1);
var isOpera = (agt.indexOf("opera") != -1);
var IEver = parseFloat(agt.substring(agt.indexOf('msie ') + 5));
var isIE = ((agt.indexOf('msie')!=-1 && !isOpera && (agt.indexOf('webtv')==-1)) && !isMac);
var isIE5win = (isIE && IEver == 5);
var isIE5mac = ((agt.indexOf("msie") != -1) && isMac);
var blnOk=true;

// onScroll pour Internet Explorer, le position:fixed fait ce boulot pour les autres navigateurs
// qui respectent les normes CSS...
window.onscroll = function()
{
	if (blnOk && suivre_le_scroll && (isIE || isIE5mac))
	{
		for(i=1;i<=nbmenu;i++)
		{
			document.getElementById("menu"+i).style.top = document.body.scrollTop + top_menu + "px";
			if (document.getElementById("ssmenu"+i))//undefined
				document.getElementById("ssmenu"+i).style.top = document.body.scrollTop + top_ssmenu + "px";
		}
	}
}

function preChargement()
{
	if (document.getElementById("conteneurmenu"))
	{
		document.getElementById("conteneurmenu").style.visibility="hidden";
		/*document.getElementById("conteneurmenu").style.float="";*/
	}
}

function Chargement() {
	if(document.body.style.backgroundColor!="") { blnOk=false; }
	if(document.body.style.color!="") { blnOk=false; }
	if(document.body.style.marginTop!="") { blnOk=false; }
	if(document.getElementById) {
		with(document.getElementById("texte").style) {
			if(position!="") { blnOk=false; }
			if(top!="") { blnOk=false; }
			if(left!="") { blnOk=false; }
			if(width!="") { blnOk=false; }
			if(height!="") { blnOk=false; }
			if(zIndex!="") { blnOk=false; }
			if(margin!="") { blnOk=false; }
			if(visibility!="") { blnOk=false; }
		}
	}
	else{
		blnOk=false;
	}

	if(blnOk)
	{
		//un contournement de bug pour IE5... qui l'utilise encore ? :-p
		trimespaces();
		
		with(document.body.style) {
			marginTop=marge_en_haut_de_page;
		}
    var leftMenu = 0;
		for(i=1;i<=nbmenu;i++) {
			with(document.getElementById("menu"+i).style) {
				top=top_menu+"px";
				left=(((i-1)*espace_entre_menus)+leftMenu+1+left_menu)+"px";
				if (!suivre_le_scroll || isIE || isIE5mac)
					position="absolute";
				else position="fixed";
				width=largeur_menu[i]+"px";
				margin="0";
				zIndex="2";
				leftMenu += largeur_menu[i];
			}
		}

		var leftMenu = 0;
		for(i=1;i<=nbmenu;i++) {
			if (document.getElementById("ssmenu"+i))//
			{
				with(document.getElementById("ssmenu"+i).style) {
					if (!suivre_le_scroll || isIE || isIE5mac)
						position="absolute";
					else position="fixed";
					top=top_ssmenu+"px";
					left=(((i-1)*espace_entre_menus)+leftMenu+1+left_menu)+"px";
					if (isIE||isOpera||isIE5mac)
						width = largeur_sous_menu[i]+(largeur_sous_menu[i]!="auto"?"px":"");
					else width = "auto";
					margin="0";
					zIndex="3";
					leftMenu += largeur_menu[i];
				}
			}
		}

		CacherMenus();
	}
	
	// comme on a �vit� le clignotement, maintenant on fait appara�tre le menu ;-)
	document.getElementById("conteneurmenu").style.visibility = "visible";
}

function MontrerMenu(strMenu) {
	if(blnOk) {
		hideSelect(); // Cache les dropdownlist
		AnnulerCacher();
		CacherMenus();
		if (document.getElementById(strMenu))//undefined
			with (document.getElementById(strMenu).style)
				visibility="visible";
	}
}

function CacherDelai() {
	if (blnOk) {
		timeout2 = setTimeout('showSelect()',delai);
		timeout = setTimeout('CacherMenus()',delai);
	}
}
function AnnulerCacher() {
	if (blnOk && timeout) {
		clearTimeout(timeout);
		clearTimeout(timeout2);
	}
}
function CacherMenus() {
	if(blnOk) {
		for(i=1;i<=nbmenu;i++) {
			if (document.getElementById("ssmenu"+i))//undefined
				with(document.getElementById("ssmenu"+i).style)
					visibility="hidden";
		}
	}
}

function trimespaces() {
	//Contourne un bug d'IE5/win... il ne capte pas bien les css pour les <li>,
	//donc on les vire !
	if(blnOk&&isIE5win) {
		for(i=1;i<=nbmenu;i++) {
			if (document.getElementById("ssmenu"+i))//undefined
				with(document.getElementById("ssmenu"+i))
					innerHTML = innerHTML.replace(/<LI>|<\/LI>/g,"");
		}
	}
}

var selectBox = new Array(0);

	function hideSelect(){
		for (i=0;i<selectBox.length;i++){
			document.all.tags("DIV")[selectBox[i]].style.visibility = "hidden";
		}
	}

	function showSelect(){
		for (i=0;i<selectBox.length;i++){
			document.all.tags("DIV")[selectBox[i]].style.visibility = "visible";
		}
	}

	// Recense toutes les balises div id=select de la page
	function getSelectBox(){
		var j = 0;
		for (i=0;i<document.all.tags("DIV").length;i++){
			if (document.all.tags("DIV")[i].id.indexOf("select") == 0){
				selectBox[j] = i;
				j++;
			}
		}
	}